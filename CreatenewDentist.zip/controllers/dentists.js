//Get all dentists
//Get /api/v1/dentists

const Dentist = require("../models/Dentist");

//public
exports.getDentists = async (req, res,next) =>{
    try{
        const dentists = await Dentist.find();
        res.status(200).json({success:true,count:dentist.length, data:hospitals});

    }catch(err){
    res.status(400).json({success:false})
    }
};

//Get single dentist
//Get /api/v1/dentists/:id
//public
exports.getDentist = (req, res,next) =>{
    res.status(200).json({success:true, msg:`Show dentist ${req.params.id}`});
};

//Create new dentist
//Get /api/v1/dentists
//private
exports.createDentist = async (req,res,next)=>{
    const dentist = await Dentist.create(req.body);
    res.status(201).json({
        success:true,
        data: dentist
    });
};
//UIpdate dentist
//Get /api/v1/dentists/:id
//public
exports.updateDentist = (req, res,next) =>{
    res.status(200).json({success:true, msg:`Update dentist ${req.params.id}`});
};

//Delete dentist
//Get /api/v1/dentists/:id
//public
exports.deleteDentist = (req, res,next) =>{
    res.status(200).json({success:true, msg:`Delete dentist ${req.params.id}`});
};